import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
@Component({
  selector: "app-homepage-desktop",
  templateUrl: "./homepage-desktop.component.html",
  styleUrls: ["./homepage-desktop.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomepageDesktopComponent {}
